<?php
include ("inc.configuration.php");

include ("modelos/model.Usuario.php");

include ("controladores/controller.Registro.php");
include ("controladores/controller.Usuario.php");

require_once ("../resources/php/class.MySQL.php");
require_once ("../resources/php/class.TemplatePower.inc.php");

?>
