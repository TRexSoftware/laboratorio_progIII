<?php
class Usuario_Controller {
public function sesion(){
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $persona = new Usuario($email,$pass);
    $existe = $persona->buscar();
    
       
    if($existe){
        $template = new TemplatePower("templates/t.html");
        $template->prepare();
    $template->gotoBlock("_ROOT");
    
        $_SESSION['user'] = $email;
       echo $template->getOutputContent();
      
    }
    else{
        $template = new TemplatePower("templates/index.html");
        echo $template->getOutputContent();

    }
}

}
?>
